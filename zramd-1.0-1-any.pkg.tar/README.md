# zramd
Initializes user-specific zram-'devices' during boot - Colored Interactive configuration tool easy-to-use 
