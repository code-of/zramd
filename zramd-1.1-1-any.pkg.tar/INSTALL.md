### **zramd** -> Installation Instructions
- Installation per script :
> Download and extract the files / Clone the repository  
> In directory of extracted/cloned files run:
       sudo chmod +x install.sh  
       sudo ./install.sh   # prefix default is: /usr change by adding prefix=/path   
-> Done  

-  Start using 'zramdconfig' for ZRAM - configuration   

***********************
 ##### Package - Installation
 - Download the .pkg - file
 - Run 'pacman -U zramd*.pkg.tar' in directory of downloaded .pkg - file   
 **********************
